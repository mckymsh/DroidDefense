# DroidDefense

Created by Team Galaga
John Hutchinson
Mickey Nash
Mitchell Bath
Paul John

Basic Sprites and objects have been implemented as proof-of-concept.

On the left is the two available turrets, a filler default turrent and the one we've beautified. Click one, then click to place. Right-click to cancel.

Enemies will spawn automatically, and forever.

Losing Condition: Running out of money.
Winning Condition: Having more than $10,000

Player starts with $10,000. 

Each enemy has a dollar value. When the enemy is killed, the player recieves that cash. If the enemy makes it to the right side of the screen, the player is deducted 1.5x that enemies value.

There is a balance to be had between building many turrets and saving up to win. Patience! Watch where the enemies go!

Ctrl+R resets the room if you're having trouble.